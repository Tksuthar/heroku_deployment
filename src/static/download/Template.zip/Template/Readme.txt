Thanks for downloading this template!

Hands on Python Web Framework Django
Created by: Tarun Kumar
Contact me @: tksuthar7463@gmail.com
